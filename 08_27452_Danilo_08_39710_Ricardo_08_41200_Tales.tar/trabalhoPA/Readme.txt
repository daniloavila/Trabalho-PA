Universidade de Brasília
Disciplina: Programação Avançada

Alunos:
 			Danilo Ávila  		xx/xxxxx
 			Ricardo Andrade  	08/39710
 			Tales Porto 		08/41200

 			
 Descrição do trabalho
 
 	O trabalho consiste em uma perseguição entre dois animais, coelho e leopardo. O coelho está confeccionado 
na cor branca e o leopardo na cor amarela. O leopardo persegue o coelho até conseguir encontrar o coelho.

Arquivo de entrada

	São definidos 2 arquivos de entrada:
	
		1. Entrada de parâmetros de execução:
			
			O arquivo entrada "entrada.txt" contém os parâmetros iniciais das posições dos animais. Seguindo a
			seguinte configuração.
			
				1.1 Direção
						q = norte
						r = nordeste
						l = leste
						s = suldeste
						n = sul
						t = sudoeste
						o = oeste
						z = noroeste
				1.2 Valor da aceleração 
				1.3 Massa
				1.4 Velocidade inicial
				1.5 Posição inicial no eixo x
				1.6 Posição inicial no eixo y
				
			Essas definições se repetem para o coelho e leopardo.
			
			O arquivo "entrada.txt" elucida um exemplo de entrada possível para o programa.

	2. Template do wrl
	
		Contém o cenário necessário para executar a simulação.
		
Execução

	Compile o programa utilizando o makefile com:
	
		make
		
	E execute com:
	
		./programa
	
	Após isso será gerado um arquivo "saida.wrl".
	
	
		

