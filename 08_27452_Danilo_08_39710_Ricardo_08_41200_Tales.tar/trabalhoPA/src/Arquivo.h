/*
 * Arquivo.h
 *
 *  Created on: 13/12/2011
 *      Author: tales
 */

#ifndef ARQUIVO_H_
#define ARQUIVO_H_

void lerParametros(animal *coelho, animal *leopardo, posicao *posicaoInicialCoelho, posicao *posicaoInicialLeopardo,
		char *arquivo);

#endif /* ARQUIVO_H_ */
